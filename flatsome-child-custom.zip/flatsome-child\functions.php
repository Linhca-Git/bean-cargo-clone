﻿<?php
// Enqueue parent and child custom styles
add_action( 'wp_enqueue_scripts', 'flatsome_child_enqueue_styles', 99 );
function flatsome_child_enqueue_styles() {
    // Enqueue parent style
    wp_enqueue_style( 'flatsome-parent-style', get_template_directory_uri() . '/style.css' );
    
    // Enqueue custom CSS containing Sapo layouts
    wp_enqueue_style( 'flatsome-child-custom', get_stylesheet_directory_uri() . '/css/custom-styles.css', array( 'flatsome-parent-style' ) );
}
